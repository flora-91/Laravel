<?php

namespace App\Http\Livewire\Components;

use Livewire\Component;

class ListUser extends Component
{
    public $user;
    public function render()
    {
        return view('livewire.components.list-user');
    }
}
