<?php

namespace App\Http\Livewire\Components;

use Livewire\Component;

class NavBar extends Component
{
    public function logout(){
        return redirect(route('logout'));
    }

    public function render()
    {
        return view('livewire.components.nav-bar');
    }
}
