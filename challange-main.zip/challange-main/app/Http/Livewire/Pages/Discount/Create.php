<?php

namespace App\Http\Livewire\Pages\Discount;

use App\Models\AccessType;
use App\Models\Brand;
use App\Models\Discount;
use App\Models\DiscountRange;
use App\Models\Region;
use Livewire\Component;

class Create extends Component
{
    public $discount;
    public $brands;
    public $access;
    public $regions;
    public $periods;


    protected $rules = [
        'discount.name' => 'required|min:5|max:30|string',
        'discount.brand_id' => 'required',
        'discount.access_type_code' => 'required',
        'discount.priority' => 'required|integer',
        'discount.region_id' => 'required',
        'discount.active' => 'required',
        'discount.start_date' => 'required|date',
        'discount.end_date' => 'required|date',
    ];

    public function mount()
    {
        $this->discount = new Discount();
        $this->discount->brand_id = 1;
        $this->discount->access_type_code = 'A';
        $this->discount->region_id = 1;
        $this->brands = Brand::all();
        $this->access = AccessType::all();
        $this->regions = Region::all();

        $this->periods = [
            [
                'from_days' => '',
                'to_days' => '',
                'code' => '',
                'discount' => '',
                'completed' => false,
            ],
            [
                'from_days' => '',
                'to_days' => '',
                'code' => '',
                'discount' => '',
                'completed' => false,
            ],
            [
                'from_days' => '',
                'to_days' => '',
                'code' => '',
                'discount' => '',
                'completed' => false,
            ],
        ];
    }

    public function periodComplete($num)
    {
        //Chekeo si es que  todos los campos estan completos Y si es que es el primero o si el anterior tambien se encuentra completo
        $this->periods[$num]['completed'] =
            !empty($this->periods[$num]['from_days'])
            && !empty($this->periods[$num]['to_days'])
            && (!empty($this->periods[$num]['discount']) || !empty($this->periods[$num]['code']))
            && ($num === 0 || $this->periods[$num - 1]['completed']);

        //utilizo recursion para chekear los que le siguen hasta el final para que no se mantengan habilitados si es que no corresponde
        if ($num < count($this->periods) - 1) {
            $this->periodComplete($num + 1);
        }
    }

    public function store()
    {
        //agrego las reglas por si alguno de los periodos se encuentra completado, en caso de no estar completado , no se agregara en el final
        foreach ($this->periods as $key => $period) {
            if ($key === 0 || $period['completed']) {
                $this->rules["periods.$key.from_days"] = "required|numeric|min:1|max:" . $period['to_days'];
                $this->rules["periods.$key.to_days"] = "required|numeric|min:" . $period['from_days'];
                $this->rules["periods.$key.code"] = empty($period['discount']) ? 'required|alpha_num:ascii' : 'alpha_num:ascii';
                $this->rules["periods.$key.discount"] = empty($period['code']) ? 'required|numeric' : 'numeric';
            }
        }

        $this->validate();
        $this->discount->save();
        foreach ($this->periods as $key => $period) {
            if ($key === 0 || $period['completed']) {
                $newPeriod = new DiscountRange(
                    [
                        'from_days' => $period['from_days'],
                        'to_days' => $period['to_days'],
                        'discount' => $period['discount'] ?? null,
                        'code' => $period['code'] ?? null,
                        'discount_id' => $this->discount->id,
                    ]
                );
                $newPeriod->save();
            }
        }
        return redirect(route('discount.index'));
    }

    public function cancel()
    {
        return redirect(route('discount.index'));
    }

    public function render()
    {
        return view('livewire.pages.discount.create');
    }
}
