<?php

namespace App\Http\Livewire\Pages\Discount;

use App\Models\Discount;
use Livewire\Component;

class Index extends Component
{
    public $discounts;
    public $modalOpen = false;
    public $selectedToDelete = -1;

    public function selectToDelete($id)
    {
        $this->selectedToDelete = $id;
        $this->modalOpen = true;
    }

    public function cancelDestroy(){
        $this->selectedToDelete = -1;
        $this->modalOpen = false;
    }

    public function destroy(){
        Discount::destroy($this->selectedToDelete);
        $this->selectedToDelete = -1;
        $this->modalOpen = false;
    }


    public function render()
    {
        $this->discounts  = Discount::all();
        return view('livewire.pages.discount.index');
    }
}
