<?php

namespace App\Http\Livewire\Pages;

use Livewire\Component;

class Landing extends Component
{
    public $usuarios = [];


    public function render()
    {
        $this->usuarios = \App\Models\User::all();
        return view('livewire.pages.landing');
    }
}
