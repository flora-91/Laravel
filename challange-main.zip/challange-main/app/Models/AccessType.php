<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class AccessType extends Model
{
    public $primaryKey = 'display_order';
    public function discount(): HasMany
    {
        return $this->hasMany(Discount::class, 'access_type_code', 'code');
    }
}
