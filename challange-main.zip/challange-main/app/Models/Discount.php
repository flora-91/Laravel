<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Discount extends Model
{
    use SoftDeletes;
    protected $guarded = []; //TODO: pasar a fillables para que no sea inseguro
    protected $attributes = ['active' => true]; //pongo por defecto el true en active
    public function discountRanges(): HasMany
    {
        return $this->hasMany(DiscountRange::class);
    }

    public function brand(): BelongsTo
    {
        return $this->belongsTo(Brand::class);
    }
    public function region(): BelongsTo
    {
        return $this->belongsTo(Region::class);
    }
    public function accessType(): BelongsTo
    {
        return $this->belongsTo(AccessType::class, 'access_type_code', 'code');
    }
}
