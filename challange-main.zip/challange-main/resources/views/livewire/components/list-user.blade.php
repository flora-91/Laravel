<div>
    {{ $user->name }} / {{ $user->email }}
</div>
