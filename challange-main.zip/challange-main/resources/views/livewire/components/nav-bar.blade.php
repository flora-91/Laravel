@auth
    <div class="w-full rounded-b top-0 grid grid-cols-6 w-100 bg-zinc-200 shadow-lg p-2 ">
        <div class="col-span-1"></div>
        <div class="col-span-4 flex justify-center align-middle"></div>
        <div class="col-span-1 flex justify-end"> <button wire:click="logout"
                class=" shadow-sm rounded text-slate-200 bg-slate-600 hover:bg-red-800 transition-all cursor-pointer p-1 px-2 ">Logout</button>
        </div>
    </div>
@endauth
