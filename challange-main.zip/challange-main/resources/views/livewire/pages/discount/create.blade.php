<div class="flex flex-col bg-slate-100 rounded-xl gap-4 p-6 justify-center items-center w-full">
    <div class="w-full flex flex-col justify-start text-left">
        <h2 class="text-xl font-bold">Alta de Descuento</h2>
        <p>En esta seccion podra dar de Alta un Descuento</p>
    </div>

    {{-- Pirmera Linea Start --}}
    <div class="shadow rounded-lg flex gap-4 p-4 justify-between items-start w-full">
        <div class="flex gap-4 justify-start items-start w-4/5">
            <label class="font-bold text-md whitespace-nowrap h-full " for="name">Nombre de la regla</label>
            <div class="flex flex-col justify-center items-start">
                <input name="discount_name" wire:model="discount.name" type="text"
                    class="rounded border-zinc-300 shadow" required maxlength="30">
                @error('discount.name')
                    <label class="text-sm text-red-600">{{ $message }}</label>
                @enderror
            </div>

            <p class="bg-zinc-400 rounded text-zinc-900 text-sm text-start p-2 whitespace-nowrap">Se permite un maximo
                de 30 caracteres</p>
        </div>
        <div class="flex w-1/5 ">
            <input name="active" type="checkbox" wire:model="discount.active" /> <label for="active"
                class="whitespace-nowrap">Activa/Inactiva</label>
        </div>
    </div>
    {{-- Pirmera Linea End --}}
    {{-- Segunda Linea Start --}}
    <div class="shadow rounded-lg grid grid-cols-4 gap-4 p-4 justify-between items-start w-full">
        <div class="flex flex-col gap-2">
            <label for="discount.brand_id">Rentadora</label>
            <select class="rounded border-zinc-300 shadow" title="brand" name="discount.brand_id"
                wire:model="discount.brand_id">
                @forelse ($brands as $brand)
                    <option value="{{ $brand->id }}">{{ $brand->name }}</option>
                @empty
                @endforelse
            </select>
            @error('discount.brand_id')
                <label class="text-sm text-red-600">{{ $message }}</label>
            @enderror
        </div>
        <div class="flex flex-col gap-2">
            <label for="discount.access_type_code">Tipo de acceso</label>
            <select class="rounded border-zinc-300 shadow" title="access" name="discount.access_type_code"
                wire:model="discount.access_type_code">
                @forelse ($access as $type)
                    <option value="{{ $type->code }}">{{ $type->name }} </option>
                @empty
                @endforelse
            </select>
            @error('discount.access_type_code')
                <label class="text-sm text-red-600">{{ $message }}</label>
            @enderror
        </div>
        <div class="flex flex-col gap-2">
            <label for="discount.priority">Prioridad</label>
            <input class="rounded border-zinc-300 shadow" type="number" wire:model="discount.priority"
                placeholder="ej: 15" />
            @error('discount.priority')
                <label class="text-sm text-red-600">{{ $message }}</label>
            @enderror
        </div>
        <div class="flex flex-col gap-2">
            <label for="discount.region_id">Region</label>
            <select class="rounded border-zinc-300 shadow" title="region" name="discount.region_id"
                wire:model="discount.region_id">
                @forelse ($regions as $region)
                    <option value="{{ $region->id }}">{{ $region->name }}</option>
                @empty
                @endforelse
            </select>
            @error('discount.region_id')
                <label class="text-sm text-red-600">{{ $message }}</label>
            @enderror
        </div>
    </div>
    {{-- Segunda Linea End --}}

    {{-- Tercer Linea Start --}}
    <div class="bg-slate-300 text-sm text-slate-600 flex p-6  rounded-lg shadow">
        <p>Desde esta seccion podra cargar otros descuentos promocionales AWD /BCD, o un descuento GSA (cediendo
            comision). Podra agregar uno o ambos descuentos al mismo tiempo. Tenga en cuenta que si una tarifa tiene
            diferentes precios por vigencia, debera definir descuentos diferentes para cada uno de ellos</p>
    </div>
    {{-- Tercer Linea End --}}
    {{-- Cuarta Linea Start --}}
    <div class="w-full flex flex-col gap-4 lg:grid lg:grid-cols-3">

        {{-- Periodo 1 start --}}
        <div class="border-zinc-200 shadow  rounded-lg" >
            <div class="@if($periods[0]['completed']) ring-1 ring-green-600 @else border-zinc-200 @endif shadow  rounded-lg">
                <div class="flex flex-col p-4 justify-start border-b border-zinc-200">
                    <p class="text-blue-900 font-bold text-sm">Periodo de aplicacion 1</p>
                    <div class="w-full flex  py-2 gap-6">
                        <div class="w-full flex flex-col gap-2">
                            <input wire:change='periodComplete(0)' class="rounded border-zinc-300 shadow" type="number"
                                wire:model="periods.0.from_days" placeholder="Desde..." />
                            @error('periods.0.from_days')
                                <label class="text-sm text-red-600">{{ $message }}</label>
                            @enderror
                        </div>
                        <div class="w-full flex flex-col gap-2">
                            <input wire:change='periodComplete(0)' class="rounded border-zinc-300 shadow" type="number" wire:model="periods.0.to_days"
                                placeholder="Hasta..." />
                            @error('periods.0.to_days')
                                <label class="text-sm text-red-600">{{ $message }}</label>
                            @enderror
                        </div>
                    </div>
                </div>
                <div class="flex flex-col p-4 gap-4 " >
                    <div class="flex flex-col gap-2">
                        <label class="text-sm font-bold" for="periods.0.code">Codigo de descuento AWD / BCD</label>
                        <input wire:change='periodComplete(0)' class="rounded border-zinc-300 shadow" type="text" wire:model="periods.0.code"
                            placeholder="Codigo..." />
                        @error('periods.0.code')
                            <label class="text-sm text-red-600">{{ $message }}</label>
                        @enderror
                    </div>
                    <div class="flex flex-col gap-2">
                        <label class="text-sm font-bold" for="periods.0.discount">Porcentaje de descuento GSA</label>
                        <input wire:change='periodComplete(0)' class="rounded border-zinc-300 shadow" type="number" wire:model="periods.0.discount"
                            placeholder="Porcentaje..." />
                        @error('periods.0.discount')
                            <label class="text-sm text-red-600">{{ $message }}</label>
                        @enderror
                    </div>
                </div>
            </div>
        </div>
            {{-- Periodo 1 end --}}
            {{-- Periodo 2 start --}}
        <div class="transition-all  shadow  rounded-lg @if(!$periods[0]['completed']) contrast-50 opacity-75 @endif @if($periods[1]['completed']) ring-1 ring-green-600 @else border-zinc-200 @endif" >
            <div class="flex flex-col p-4 justify-start border-b border-zinc-200">
                <p class="text-blue-900 font-bold text-sm">Periodo de aplicacion 2 </p>
                <div class="flex py-2 gap-6">
                    <div class="w-full flex flex-col gap-2">
                        <input wire:change='periodComplete(1)' @disabled(!$periods[0]['completed']) class="rounded border-zinc-300 shadow" type="number" wire:model="periods.1.from_days"
                            placeholder="Desde..." />
                        @error('periods.1.from_days')
                            <label class="text-sm text-red-600">{{ $message }}</label>
                        @enderror
                    </div>
                    <div class="w-full flex flex-col gap-2">
                        <input wire:change='periodComplete(1)' @disabled(!$periods[0]['completed']) class="rounded border-zinc-300 shadow" type="number" wire:model="periods.1.to_days"
                            placeholder="Hasta..." />
                        @error('periods.1.to_days')
                            <label class="text-sm text-red-600">{{ $message }}</label>
                        @enderror
                    </div>
                </div>
            </div>
            <div class="flex flex-col p-4 gap-4 ">
                <div class="flex flex-col gap-2">
                    <label class="text-sm font-bold" for="periods.1.code">Codigo de descuento AWD / BCD</label>
                    <input wire:change='periodComplete(1)' @disabled(!$periods[0]['completed']) class="rounded border-zinc-300 shadow" type="number" wire:model="periods.1.code"
                        placeholder="Codigo..." />
                    @error('periods.1.code')
                        <label class="text-sm text-red-600">{{ $message }}</label>
                    @enderror
                </div>
                <div class="flex flex-col gap-2">
                    <label class="text-sm font-bold" for="periods.1.discount">Porcentaje de descuento GSA</label>
                    <input wire:change='periodComplete(1)'  @disabled(!$periods[0]['completed']) class="rounded border-zinc-300 shadow" type="number" wire:model="periods.1.discount"
                        placeholder="Porcentaje..." />
                    @error('periods.1.discount')
                        <label class="text-sm text-red-600">{{ $message }}</label>
                    @enderror
                </div>
            </div>
        </div>
        {{-- Periodo 2 end --}}
            {{-- Periodo 3 start --}}
            <div class="transition-all border-zinc-200 shadow  rounded-lg @if(!$periods[1]['completed']) contrast-50 opacity-75 @endif @if($periods[2]['completed']) ring-1 ring-green-600 @else border-zinc-200 @endif" >
                <div class="flex flex-col p-4 justify-start border-b border-zinc-200">
                <p class="text-blue-900 font-bold text-sm">Periodo de aplicacion 3</p>
                <div class="flex py-2 gap-6">
                    <div class="w-full flex flex-col gap-2">
                        <input @disabled(!$periods[1]['completed']) class="rounded border-zinc-300 shadow" type="number" wire:model="periods.2.from_days"
                            placeholder="Desde..." />
                        @error('periods.2.from_days')
                            <label class="text-sm text-red-600">{{ $message }}</label>
                        @enderror
                    </div>
                    <div class="w-full flex flex-col gap-2">
                        <input @disabled(!$periods[1]['completed']) class="rounded border-zinc-300 shadow" type="number" wire:model="periods.2.to_days"
                            placeholder="Hasta..." />
                        @error('periods.2.to_days')
                            <label class="text-sm text-red-600">{{ $message }}</label>
                        @enderror
                    </div>
                </div>
            </div>
            <div class="flex flex-col p-4 gap-4 ">
                <div class="flex flex-col gap-2">
                    <label class="text-sm font-bold" for="periods.2.code">Codigo de descuento AWD / BCD</label>
                    <input @disabled(!$periods[1]['completed']) class="rounded border-zinc-300 shadow" type="text" wire:model="periods.2.code"
                        placeholder="Codigo..." />
                    @error('periods.2.code')
                        <label class="text-sm text-red-600">{{ $message }}</label>
                    @enderror
                </div>
                <div class="flex flex-col gap-2">
                    <label class="text-sm font-bold" for="periods.2.discount">Porcentaje de descuento GSA</label>
                    <input @disabled(!$periods[1]['completed']) class="rounded border-zinc-300 shadow" type="number" wire:model="periods.2.discount"
                        placeholder="Porcentaje..." />
                    @error('periods.2.discount')
                        <label class="text-sm text-red-600">{{ $message }}</label>
                    @enderror
                </div>
            </div>
        </div>

    </div>
    {{-- Cuarta Linea End --}}
    {{-- Quinta Linea start --}}
    <div class="flex p-4 gap-4 justify-start items-center w-full shadow border-zinc-300 rounded ">
        <label class="font-bold text-md whitespace-nowrap h-full " for="name">Periodo de Aplicacion</label>
        <div class="flex justify-center items-center gap-2">
            <span> Desde </span>
            <input name="discount.start_date" wire:model="discount.start_date" type="date" class="rounded border-zinc-300 shadow" required >
            <span> Hasta </span>
            <input name="discount.end_date" wire:model="discount.end_date" type="date" class="rounded border-zinc-300 shadow" required >
            @error('discount.start_date')
                <label class="text-sm text-red-600">{{ $message }}</label>
            @enderror
            @error('discount.end_date')
                <label class="text-sm text-red-600">{{ $message }}</label>
            @enderror
        </div>

        <p class="bg-zinc-400 rounded text-zinc-900 text-sm text-start p-2 whitespace-nowrap">Utilice esta seccon para definir el periodo de aplicacion de la regla de negocio</p>
    </div>
    {{-- Quinta Linea End --}}

    <div class="w-full flex justify-end gap-4">
        <button class="transition-all  p-4 py-2 rounded shadow hover:bg-zinc-200 " wire:click='cancel'>Cancelar</button>
        <button class="transition-all p-4 py-2 bg-blue-800 hover:bg-blue-950 text-zinc-200 rounded shadow " wire:click='store'>Enviar</button>
    </div>

</div>
