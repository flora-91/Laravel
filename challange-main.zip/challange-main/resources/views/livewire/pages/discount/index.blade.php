<div class=" bg-slate-200 flex flex-col p-8 gap-4">
    <div
        class="absolute @if ($modalOpen) z-50 @else hidden @endif w-screen h-screen inset-0  backdrop-blur-sm grid place-items-center">
        <div class="relative bottom-12 rounded shadow-lg p-8 flex flex-col gap-4 min-w-md bg-zinc-200 ">
            <h2>¿Confirma la eliminacion del registro?</h2>
            <div class="flex justify-between w-100 gap-2 ">
                <button class="rounded p-4 py-2 shadow bg-zinc-300 hover:bg-zinc-400 text-zinc-900"
                    wire:click="cancelDestroy">Cancelar</button>
                <button class="rounded p-4 py-2 shadow bg-red-900 hover:bg-red-950 text-zinc-100"
                    wire:click="destroy">Eliminar</button>
            </div>
        </div>
    </div>
    <div class="flex justify-between items-center p-2 align-middle ">
        <div class="flex flex-col gap-2 ">
            <h2 class="text-lg text-slate-950 font-weight-bolder">Descuentos</h2>
            <p class="text-sm text-slate-700">En esta seccion se podra ver y configurar los descuentos que se aplicaran
                a
                todo el sitio</p>
        </div>
        <div class="flex justify-end items-center gap-2 align-middle h-full">
            <a href="{{ route('discount.create') }}"
                class="text-nowrap whitespace-nowrap h-12 p-1 px-2  rounded-lg text-slate-200 bg-blue-900 hover:bg-blue-950 transition-all">Nuevo
                descuento</a>
            <button
                class=" h-12 text-nowrap px-2 py-1 rounded-lg text-slate-700 bg-slate-400 hover:bg-slate-300 transition-all">Exportar</button>
        </div>
    </div>
    {{-- FILTROS START --}}
    <div class="flex justify-between items-center p-6 bg-white rounded-xl  shadow">
        {{-- Inputs de filtros --}}
        <div class="grid grid-cols-5 gap-4 justify-center items-center">
            <div class="flex flex-col gap-2">
                <p>Label</p>
                <select name="" id=""></select>
            </div>
            <div class="flex flex-col gap-2">
                <p>Label</p>
                <select name="" id=""></select>
            </div>
            <div class="flex flex-col gap-2 col-span-2">
                <p>Label</p>
                <input type="text">
            </div>
            <div class="flex flex-col gap-2">
                <p>Label</p>
                <input type="text">
            </div>
        </div>
        {{-- Inputs de filtros --}}
        {{-- Botonera --}}
        <div class="flex justify-between gap-2 ">
            <div class="flex flex-col gap-2">
                <p></p>
                <button
                    class="text-nowrap whitespace-nowrap h-12 p-1 px-2  rounded-lg text-slate-200 bg-blue-900 hover:bg-blue-950 transition-all">Buscar</button>

            </div>
            <div class="flex flex-col gap-2">
                <p></p>
                <button
                    class=" h-12 text-nowrap px-2 py-1 rounded-lg text-slate-700 bg-slate-400 hover:bg-slate-300 transition-all">Quitar
                    filtros</button>
            </div>
        </div>
        {{-- Botonera --}}
    </div>
    {{-- FILTROS END --}}

    {{-- Listado Start --}}
    <div class="flex flex-col p-6 gap-2 bg-white rounded-xl shadow">
        <div class="grid grid-cols-12 py-2  items-center border-b-2 border-zinc-300">
            {{-- Titulos start --}}
            <div class=" border-x border-zinc-300 px-1 col-span-auto font-semibold">Rentadora</div>
            <div class=" border-x border-zinc-300 px-1 col-span-auto font-semibold">Region</div>
            <div class=" border-x border-zinc-300 px-1 col-span-auto font-semibold">Nombre</div>
            <div class=" border-x border-zinc-300 px-1 col-span-auto font-semibold">Tipo de acceso</div>
            <div class=" border-x border-zinc-300 px-1 col-span-auto font-semibold">Estado</div>
            <div class=" border-x border-zinc-300 px-1 col-span-auto font-semibold">Periodo</div>
            <div class=" border-x border-zinc-300 px-1 col-span-auto font-semibold">AWD/BCD</div>
            <div class=" border-x border-zinc-300 px-1 col-span-auto font-semibold">Descuento de GSA</div>
            <div class=" border-x border-zinc-300 px-1 col-span-2 font-semibold">Periodo de promocion</div>
            <div class=" border-x border-zinc-300 px-1 col-span-auto font-semibold">Prioridad</div>
            <div class=" border-x border-zinc-300 px-1 col-span-2 font-semibold"></div>
        </div>
        <div class="grid grid-cols-12 gap-1 items-center">
            {{-- Titulos  end --}}
            @forelse ($discounts as $discount)
                <div class="col-span-auto font-semibold">{{ $discount->brand->name }}</div>
                <div class="col-span-auto font-semibold">{{ $discount->region->name }}</div>
                <div class="col-span-auto font-semibold">{{ $discount->name }}</div>
                <div class="col-span-auto font-semibold">{{ $discount->access_type_code }}</div>
                <div class="col-span-auto font-semibold">{{ $discount->active ? 'Activo' : 'Inactivo' }}</div>
                <div class="col-span-auto font-semibold flex flex-col">
                    @forelse ($discount->discountRanges as $range)
                        <p>{{ $range->from_days . ' - ' . $range->to_days }}</p>
                    @empty
                    @endforelse
                </div>
                <div class="col-span-auto font-semibold">
                    @forelse ($discount->discountRanges as $range)
                        <p>{{ $range->code }}</p>
                    @empty
                        <p>--</p>
                    @endforelse
                </div>
                <div class="col-span-auto font-semibold">
                    @forelse ($discount->discountRanges as $range)
                        <p>{{ $range->discount }}</p>
                    @empty
                        <p>--</p>
                    @endforelse
                </div>
                <div class="col-span-2">
                    <div class=" font-semibold flex flex-col flex-nowrap text-nowrap">
                        <p class="whitespace-nowrap">{{ $discount->start_date }}</p>
                        <p class="whitespace-nowrap">{{ $discount->end_date }}</p>
                    </div>
                </div>
                <div class="col-span-auto font-semibold">{{ $discount->priority }}</div>
                <div class="col-span-1 font-semibold">
                    <button
                        class="text-nowrap whitespace-nowrap h-12 p-1 px-2  rounded-lg text-slate-200 bg-blue-900 hover:bg-blue-950 transition-all">Editar</button>
                    <button wire:click='selectToDelete({{ $discount->id }})'
                        class="text-nowrap whitespace-nowrap h-12 p-1 px-2  rounded-lg text-slate-200 bg-red-900 hover:bg-red-950 transition-all">Eliminar</button>
                </div>
            @empty
                <h2 class="col-span-12 text-center p-6 text-lg bg-slate-200">No se encontraron registros sobre la
                    busqueda</h2>
            @endforelse
        </div>
    </div>



    {{-- Listado End --}}
</div>
