<div class="flex flex-col gap-2 w-full">



    @forelse ($usuarios as $user)
        <livewire:components.list-user :user="$user" />
    @empty
        <h2>No hay usuarios en la base</h2>
    @endforelse

</div>
